package com.microservicio.hospital.hospital.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.microservicio.hospital.hospital.model.Paciente;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Long> {
    //JPA QUERY
    @Query("SELECT p FROM Paciente WHERE p.apellido = :apellidoPaciente")
    List<Paciente> pacientesPorApellido(@Param("apellido") String apellidoPaciente );
    //SQL NATIVO
    @Query(value = "SELECT * FROM Paciente WHERE run = :rut", nativeQuery = true)
    Paciente buscarPacientePorRun(@Param("run") String rut);

}
