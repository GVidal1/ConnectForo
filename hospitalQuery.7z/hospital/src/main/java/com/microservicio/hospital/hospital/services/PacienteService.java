package com.microservicio.hospital.hospital.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservicio.hospital.hospital.model.Paciente;
import com.microservicio.hospital.hospital.repository.PacienteRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PacienteService {

    @Autowired
    private PacienteRepository pacienteRepository;

    public List<Paciente> listarPacientes() {
        return pacienteRepository.findAll();
    }

    public Paciente encontrarPaciente(Long id) {
        return pacienteRepository.findById(id).orElseThrow(() -> new RuntimeException("Paciente No encontrado"));
    }

    public Paciente guardarPaciente(Paciente paciente){
        return pacienteRepository.save(paciente);
    }

    public void  borrarPaciente(Long id){
        pacienteRepository.deleteById(id);
    }

    public List<Paciente> buscarPacientesPorApellido(String apellido) {
        return pacienteRepository.pacientesPorApellido(apellido);
    }

    public Paciente actualizarPaciente(Long id, Paciente paciente) {
        Paciente pacienteActual = encontrarPaciente(id);

        pacienteActual.setIdPaciente(id);

        if (pacienteActual.getRun() != null) {
            pacienteActual.setRun(paciente.getRun());
          }
      
          if (pacienteActual.getNombre() != null) {
            pacienteActual.setNombre(paciente.getNombre());
          }
      
          if (pacienteActual.getApellido() != null) {
            pacienteActual.setApellido(paciente.getApellido());
          }

          if (pacienteActual.getCorreo() != null) {
            pacienteActual.setCorreo(paciente.getCorreo());
          }

          if (pacienteActual.getFechaNacimiento() != null) {
            pacienteActual.setFechaNacimiento(paciente.getFechaNacimiento());
          }
      
          return pacienteRepository.save(pacienteActual);
    }
    
}
