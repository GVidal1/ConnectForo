package com.microservicio.hospital.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservicio.hospital.hospital.model.Paciente;
import com.microservicio.hospital.hospital.services.PacienteService;


@RestController
@RequestMapping("api/v1/pacientes")
public class PacienteController {

    @Autowired
    private PacienteService pacienteService;


    @GetMapping()
    public ResponseEntity<List<Paciente>> obtenerListaPacientes() {
        //guardar en una lista nueva los elementos
        List<Paciente> pacientes = pacienteService.listarPacientes();
        if(pacientes.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(pacientes);

        // return ResponseEntity.ok(pacienteService.listarPacientes());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Paciente> encontrarPaciente(@PathVariable Long id) {
        try {
            Paciente pac = pacienteService.encontrarPaciente(id);
            return ResponseEntity.ok(pac);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{apellidoPaciente}")
    public ResponseEntity<List<Paciente>> buscarPacientesPorApellido(@PathVariable String apellidoPaciente) {
        return ResponseEntity.ok(pacienteService.buscarPacientesPorApellido(apellidoPaciente));
    }

    @DeleteMapping("/{idPaciente}")
    public ResponseEntity<?> borrarPaciente(@PathVariable Long idPaciente) {
        try {
            Paciente pac = pacienteService.encontrarPaciente(idPaciente);
            return ResponseEntity.ok(pac);
        }  catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping()
    public ResponseEntity<Paciente> guardarPaciente(@RequestBody Paciente paciente) {
        Paciente pac = pacienteService.guardarPaciente(paciente);

        return ResponseEntity.status(HttpStatus.CREATED).body(pac);
    }

    @PutMapping("/{idPaciente}")
    public ResponseEntity<Paciente> actualizarDatosPaciente(@PathVariable Long idPaciente, @RequestBody Paciente paciente) {
        try {
            Paciente pac = pacienteService.encontrarPaciente(idPaciente);
            return ResponseEntity.ok(pacienteService.actualizarPaciente(idPaciente, paciente));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

}
