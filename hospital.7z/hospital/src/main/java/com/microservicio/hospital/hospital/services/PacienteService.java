package com.microservicio.hospital.hospital.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservicio.hospital.hospital.model.Paciente;
import com.microservicio.hospital.hospital.repository.PacienteRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PacienteService {

    @Autowired
    private PacienteRepository pacienteRepository;

    public List<Paciente> listarPacientes() {
        return pacienteRepository.findAll();
    }

    public Paciente encontrarPaciente(Long id) {
        return pacienteRepository.findById(id).orElseThrow(() -> new RuntimeException("Paciente No encontrado"));
    }

    public Paciente guardarPaciente(Paciente paciente){
        return pacienteRepository.save(paciente);
    }

    public void borrarPaciente(Long id){
        pacienteRepository.deleteById(id);
    }
    
}
