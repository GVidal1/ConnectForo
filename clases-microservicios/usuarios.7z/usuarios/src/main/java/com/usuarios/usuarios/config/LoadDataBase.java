package com.usuarios.usuarios.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.usuarios.usuarios.model.Rol;
import com.usuarios.usuarios.model.Usuario;
import com.usuarios.usuarios.repository.RolRepository;
import com.usuarios.usuarios.repository.UsuarioRepository;

//Cargar datos iniiales si las tablas estan vacias
@Configuration
public class LoadDataBase {

    @Bean
    CommandLineRunner initDataBase(RolRepository rolRepository, UsuarioRepository usuarioRepository) {
        return args -> {
            if (rolRepository.count() == 0 && usuarioRepository.count() == 0) {
                Rol admin = new Rol();
                admin.setNombre("Administrador");
                rolRepository.save(admin);
                
                Rol user =  new Rol();
                user.setNombre("Usuario");
                rolRepository.save(user);


                usuarioRepository.save(new Usuario(null, admin, "vicros","123456"));
                usuarioRepository.save(new Usuario(null, user, "Gabriel", "12345"));

                System.out.println("Datos");
            }
        };
    }
}
