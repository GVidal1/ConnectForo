package com.usuarios.usuarios.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usuarios.usuarios.model.Rol;
import com.usuarios.usuarios.model.Usuario;
import com.usuarios.usuarios.repository.RolRepository;
import com.usuarios.usuarios.repository.UsuarioRepository;

@Service
public class UsuariosService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private RolRepository rolRepository;

    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    public Usuario buscarUsuarioPorId(Long id) {
        return usuarioRepository.findById(id).orElseThrow(() -> new RuntimeException("No se ha encontrado el usuario"));
    }

    public Usuario crearUsuario(String user, String pass, Long idRol) {
        Rol roles = rolRepository.findById(idRol).orElseThrow(() -> new RuntimeException("No se encontro el Rol"));

        Usuario user1 = new Usuario();
        user1.setUserName(user);
        user1.setPassword(pass);
        user1.setRol(roles);

        return usuarioRepository.save(user1);
    }
}
