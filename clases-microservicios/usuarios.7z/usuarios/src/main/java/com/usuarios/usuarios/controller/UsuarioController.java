package com.usuarios.usuarios.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.usuarios.usuarios.model.Rol;
import com.usuarios.usuarios.model.Usuario;
import com.usuarios.usuarios.services.RolesService;
import com.usuarios.usuarios.services.UsuariosService;
import org.springframework.web.bind.annotation.PostMapping;


@RestController
@RequestMapping("api/v1")
public class UsuarioController {

    @Autowired
    private UsuariosService usuariosService;

    @Autowired
    private RolesService rolesService;


    @GetMapping("/users")
    public ResponseEntity<List<Usuario>> listaDeUsuarios() {
        List<Usuario> usuarios = usuariosService.listarUsuarios();

        if(usuarios.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(usuarios);
    }
    

    @GetMapping("/roles")
    public ResponseEntity<List<Rol>> listaDeRoles() {
        List<Rol> roles = rolesService.listarRoles();
        if(roles.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(roles);
    }


    @PostMapping("/users")
    public ResponseEntity<?> crearUsuario(@RequestParam String userName, @RequestParam String password, @RequestParam Long idRol) {
        try {
            Usuario newUser = usuariosService.crearUsuario(userName, password, idRol);
            return ResponseEntity.status(HttpStatus.CREATED).body(newUser);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e);
        }
    }
    
}
