package com.usuarios.usuarios.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usuarios.usuarios.model.Rol;
import com.usuarios.usuarios.repository.RolRepository;

@Service
public class RolesService {

    @Autowired
    private RolRepository rolRepository;

    public List<Rol> listarRoles() {
        return rolRepository.findAll();
    }

    public Rol rolPorId(Long id) {
        return rolRepository.findById(id).orElseThrow(() -> new RuntimeException("No se ha encontrado el rol"));
    }

}
