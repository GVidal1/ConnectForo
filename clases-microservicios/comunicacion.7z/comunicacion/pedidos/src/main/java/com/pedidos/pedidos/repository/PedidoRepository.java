package com.pedidos.pedidos.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pedidos.pedidos.model.Pedidos;

@Repository
public interface PedidoRepository extends JpaRepository<Pedidos, Long> {

}
