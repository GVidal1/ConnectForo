package com.pedidos.pedidos.services;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pedidos.pedidos.client.ClientesClient;
import com.pedidos.pedidos.model.Pedidos;
import com.pedidos.pedidos.repository.PedidoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ClientesClient clientesClient;

    public List<Pedidos> listarPedidos() {
        return pedidoRepository.findAll();
    }

    public Pedidos guardarPedido(Pedidos pedidoNuevo) {
        //verificar si el id del cliente existe para crear un nuevo pedido ya que no puede existir sin un idCliente
        Map<String, Object> clientes = clientesClient.getClientePorId(pedidoNuevo.getIdCliente());

        if (clientes == null || clientes.isEmpty()) {
            throw new RuntimeException("Cliente no encontrado no se puede agregar el pedido");
        }

        return pedidoRepository.save(pedidoNuevo);
    }
}
