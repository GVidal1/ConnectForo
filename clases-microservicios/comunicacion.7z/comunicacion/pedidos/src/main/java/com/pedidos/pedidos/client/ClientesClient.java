package com.pedidos.pedidos.client;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

//para que se pueda comunicar
@Component
public class ClientesClient {
    //varible de comunicacion
    private final WebClient webClient;

    //Metodo constructor 
    public ClientesClient(@Value("${cliente-service.url}") String clienteServiceUrl) {
        this.webClient = WebClient.builder().baseUrl(clienteServiceUrl).build();
    }

    //metodo para realizar la consunlta de getMapping("id") del microservicio de cliente
    @SuppressWarnings("unchecked")
    public Map<String, Object> getClientePorId(Long id) {
        return this.webClient.get()
            .uri("/{id}", id)
            .retrieve()
            .onStatus(status -> status.is4xxClientError(), response -> response.bodyToMono(String.class).map(body -> new RuntimeException("Cliente no encontrado")))
            .bodyToMono(Map.class).block();
            }
}
