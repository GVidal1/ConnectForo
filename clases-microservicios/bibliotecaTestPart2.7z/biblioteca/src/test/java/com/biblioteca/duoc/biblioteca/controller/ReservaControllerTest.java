package com.biblioteca.duoc.biblioteca.controller;

import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;        // Import para GET
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;     // Import para status
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;   // Import para jsonPath

import java.util.Date;
import java.util.List;
import java.util.Arrays;  

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.biblioteca.duoc.biblioteca.model.Reserva;
import com.biblioteca.duoc.biblioteca.service.ReservaService;

//SIMULA LA ARQUITECTURA DE MVC
//PRUEBA UNITARIA DE ARQUITECTURA TEST DE UN CONTROLLADOR (ENDPOINT)
//cargar el controllador que se va a simular
@WebMvcTest(ReservaController.class)
public class ReservaControllerTest {

    //Mock para simular el servicio del endPoint
    //Que se ejecute automaticamente por eso es un Bean
    @MockBean
    private ReservaService reservaService;

    //crear un mock proporionado por SpringBoot
    //Controllador del mismo tipo que el de SpringBoot
    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Implementacion de nuevo objeto Reserva y respuesta 200 OK")
    void testListaReservaJsonAndOK() throws Exception {
        //Crear un reserva ficticia para la respuesta del servicio
        List<Reserva> listaReserva = Arrays.asList(new Reserva(1L, new Date(), new Date(), new Date(), "1", null, null));

        //idenitificar el comportamiuentop del sericio
        when(reservaService.listar()).thenReturn(listaReserva);

        
        // Ejecutar petición GET al endpoint y validar respuesta HTTP y contenido JSON
        //Ejecutar la funcion del controlador
        //Ejecutar el metodo GET (endpoint)
        //verficar que la respuesta sea 200 OK
        //validar que el archivo json contenga los id
        mockMvc.perform(get("/api/v1/reserva"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$[0].id").value(1));
    }

}
