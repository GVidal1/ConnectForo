package com.biblioteca.duoc.biblioteca.service;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
//Libreria para hacer la comparacion
import static org.assertj.core.api.Assertions.assertThat;
import com.biblioteca.duoc.biblioteca.model.TipoSala;
import com.biblioteca.duoc.biblioteca.repository.TipoSalaRepository;

//HABILITACION AUTOMATICA DE LOS MOCKS
//mocks: crear elementos ficticios para cualquier parte de nuestro programa.
@ExtendWith(MockitoExtension.class) 
public class TipoSalaServiceTest {
    //identificar para crear el repositorio ficticio (copia)
    @Mock
    private TipoSalaRepository tipoSalaRepository;

    //Objeto de prueba para injectar datos ficticio
    @InjectMocks
    private TipoSalaService tipoSalaService;
    
    //identificamos que es una prueba unitaria
    @Test
    @DisplayName("Implementacion de nuevos objetos en la base de datos")
    void testListGetAllTiposSalas() {
        // crear un elemto simulado la respuesta de repository
        // Hacer una lista que simule un getAll para ñla lista
        //Se inicializa una lista con un elemento
        List<TipoSala> listaMockTipoSalas = Arrays.asList(new TipoSala(1L, "Auditorio" ));

        //Definir el comportamiento del Mock en este caso Repositorio
        when(tipoSalaRepository.findAll()).thenReturn(listaMockTipoSalas);

        // Ejecutar el metodo a probar
        List<TipoSala> result = tipoSalaService.listarSalas();

        // Verificar el resultado (CRITERIOS DE ACEPTACION)
        assertThat(result).isEqualTo(listaMockTipoSalas);
    }
}
