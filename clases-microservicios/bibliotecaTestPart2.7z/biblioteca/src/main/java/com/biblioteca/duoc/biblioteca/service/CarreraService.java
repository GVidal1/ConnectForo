package com.biblioteca.duoc.biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biblioteca.duoc.biblioteca.model.Carrera;
import com.biblioteca.duoc.biblioteca.repository.CarreraRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CarreraService {

    @Autowired
    private CarreraRepository carreraRepository;

    public List<Carrera> listar(){
        return carreraRepository.findAll();
    }

    public Carrera buscarPorId(String codigo){
        return carreraRepository.findById(codigo).orElseThrow(() -> new RuntimeException("No encontrado"));
    }

    public Carrera guardarNuevo(Carrera nuevoElemento){
        return carreraRepository.save(nuevoElemento);
    }

    public void eliminarPorId(String codigo){
        Carrera CarreraActual = buscarPorId(codigo);
        carreraRepository.deleteById(CarreraActual.getCodigo());
    }
}
