package com.biblioteca.duoc.biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biblioteca.duoc.biblioteca.model.Reserva;
import com.biblioteca.duoc.biblioteca.repository.ReservaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ReservaService {

    @Autowired
    private ReservaRepository reservaRepository;

    public List<Reserva> listar(){
        return reservaRepository.findAll();
    }

    public Reserva buscarPorId(Long id){
        return reservaRepository.findById(id).orElseThrow(() -> new RuntimeException("No encontrado"));
    }

    public Reserva guardarNuevo(Reserva nuevoElemento){
        return reservaRepository.save(nuevoElemento);
    }

    public void eliminarPorId(Long id){
        Reserva ReservaActual = buscarPorId(id);
        reservaRepository.deleteById(ReservaActual.getId());
    }
}
