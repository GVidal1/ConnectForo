package com.biblioteca.duoc.biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biblioteca.duoc.biblioteca.model.TipoSala;
import com.biblioteca.duoc.biblioteca.repository.TipoSalaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class TipoSalaService {

    @Autowired
    private TipoSalaRepository tipoSalaRepository;

    public List<TipoSala> listarSalas(){
        return tipoSalaRepository.findAll();
    }

    public TipoSala buscarTipoSalaPorId(Long id){
        return tipoSalaRepository.findById(id).orElseThrow(() -> new RuntimeException("No encontrado"));
    }

    public TipoSala guardarTipoSalaNueva(TipoSala nuevoElemento){
        return tipoSalaRepository.save(nuevoElemento);
    }

    public void eliminarTipoSalaPorId(Long id){
        TipoSala salaActual = buscarTipoSalaPorId(id);
        tipoSalaRepository.deleteById(salaActual.getId());
    }
}
