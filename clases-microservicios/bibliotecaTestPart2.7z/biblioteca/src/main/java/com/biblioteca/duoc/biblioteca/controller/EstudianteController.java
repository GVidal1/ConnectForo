package com.biblioteca.duoc.biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biblioteca.duoc.biblioteca.model.Estudiante;
import com.biblioteca.duoc.biblioteca.service.EstudianteService;

@RestController
@RequestMapping("/api/v1/estudiante")
public class EstudianteController {

    @Autowired
    private EstudianteService estudianteService;

    @GetMapping
    public List<Estudiante> getAll() {
        return estudianteService.listar();
    }

    @GetMapping("{/id}")
    public Estudiante getById(@PathVariable Long id) {
        return estudianteService.buscarPorId(id);
    }

    @PostMapping
    public Estudiante createEstudiante(@RequestBody Estudiante Estudiante){
        return estudianteService.guardarNuevo(Estudiante);
    }

    @DeleteMapping("/{id}")
    public void deleteEstudiante(@PathVariable Long id){
        estudianteService.eliminarPorId(id);
    }
}
