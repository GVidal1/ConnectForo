package com.biblioteca.duoc.biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biblioteca.duoc.biblioteca.model.Estudiante;
import com.biblioteca.duoc.biblioteca.repository.EstudianteRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class EstudianteService {

    @Autowired
    private EstudianteRepository estudianteRepository;

    public List<Estudiante> listar(){
        return estudianteRepository.findAll();
    }

    public Estudiante buscarPorId(Long id){
        return estudianteRepository.findById(id).orElseThrow(() -> new RuntimeException("No encontrado"));
    }

    public Estudiante guardarNuevo(Estudiante nuevoElemento){
        return estudianteRepository.save(nuevoElemento);
    }

    public void eliminarPorId(Long id){
        Estudiante EstudianteActual = buscarPorId(id);
        estudianteRepository.deleteById(EstudianteActual.getId());
    }
}
