package com.biblioteca.duoc.biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biblioteca.duoc.biblioteca.model.Sala;
import com.biblioteca.duoc.biblioteca.repository.SalaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class SalaService {

    @Autowired
    private SalaRepository salaRepository;

    public List<Sala> listar(){
        return salaRepository.findAll();
    }

    public Sala buscarPorId(Long id){
        return salaRepository.findById(id).orElseThrow(() -> new RuntimeException("No encontrado"));
    }

    public Sala guardarNuevo(Sala nuevoElemento){
        return salaRepository.save(nuevoElemento);
    }

    public void eliminarSalaPorId(Long id){
        Sala salaActual = buscarPorId(id);
        salaRepository.deleteById(salaActual.getId());
    }
}
