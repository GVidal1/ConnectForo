package com.biblioteca.duoc.biblioteca.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "sala")
public class Sala {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    @Column(name = "numero_sillas", nullable = false)
    private Integer numeroSillas;

    @Column(name = "id_instituto", nullable = false)
    private Integer idInstituto;

    @Column(name = "id_tipo_sala", nullable = false)
    @JoinColumn(name = "id", nullable = false)
    private TipoSala idTipoSala; 
}
