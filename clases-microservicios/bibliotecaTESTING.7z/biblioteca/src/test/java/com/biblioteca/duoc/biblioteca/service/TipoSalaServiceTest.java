package com.biblioteca.duoc.biblioteca.service;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.biblioteca.duoc.biblioteca.model.TipoSala;
import com.biblioteca.duoc.biblioteca.repository.TipoSalaRepository;

//HABILITACION AUTOMATICA DE LOS MOCKS
//mocks: crear elementos ficticios para cualquier parte de nuestro programa.
@ExtendWith(MockitoExtension.class) 
public class TipoSalaServiceTest {
    //identificar para crear el repositorio ficticio (copia)
    @Mock
    private TipoSalaRepository tipoSalaRepository;

    //Objeto de prueba para injectar datos ficticio
    @InjectMocks
    private TipoSalaService tipoSalaService;

    //creacion de elementos de prueba
    private TipoSala tipoSala1;
    private TipoSala tipoSala2;
    

    //identificamos que es una prueba unitaria
    @Test
    @DisplayName("Implementacion de nuevos objetos en la base de datos")
    void testGetAllTiposSalas() {
        when(tipoSalaRepository.findAll())
    }
}
